"""Integration checks for distributable artifacts, using only the stdlib."""
import hashlib
import importlib.util
import json
import pathlib
import posixpath
import re
import shutil
import subprocess
import tempfile
import unittest
import zipfile
from unittest import mock

ROOT = pathlib.Path(__file__).resolve().parents[1]


class RepositoryReleaseTests(unittest.TestCase):
    @unittest.skipUnless((ROOT / ".git").exists() and shutil.which("git"),
                         "source archive has no Git checkout metadata")
    def test_required_release_files_are_tracked_in_checkout(self):
        spec = importlib.util.spec_from_file_location("release", ROOT / "scripts/release.py")
        release = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(release)
        result = subprocess.run(["git", "-C", str(ROOT), "ls-files", "-z"],
                                check=True, capture_output=True)
        tracked = set(result.stdout.decode("utf-8").split("\0"))
        missing = sorted(set(release.ROOT_FILES) - tracked)
        self.assertEqual(missing, [],
                         "Required release files absent from Git checkout: " + ", ".join(missing))

    def missing_document_links(self, documents, available):
        missing = []
        for name, contents in documents.items():
            for target in re.findall(r"\]\(([^)]+)\)", contents):
                path = target.split("#", 1)[0]
                if not path.endswith(".md") or path.startswith(("http:", "https:")):
                    continue
                destination = posixpath.normpath(posixpath.join(posixpath.dirname(name), path))
                if destination not in available:
                    missing.append(f"{name} -> {target}")
        return missing

    def test_repository_document_links_resolve(self):
        files = list(ROOT.glob("*.md")) + list((ROOT / "Changelogs").glob("*.md"))
        documents = {p.relative_to(ROOT).as_posix(): p.read_text(encoding="utf-8-sig")
                     for p in files}
        self.assertEqual(self.missing_document_links(documents, documents), [])

    def test_repository_archive_contains_reports_and_linked_documents(self):
        spec = importlib.util.spec_from_file_location("release", ROOT / "scripts/release.py")
        release = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(release)
        reports = {p.relative_to(ROOT).as_posix()
                   for p in (ROOT / "Changelogs").glob("VERIFICHE-*.md")}
        self.assertTrue(reports, "verification reports must exist in Changelogs")
        with tempfile.TemporaryDirectory() as temporary:
            output = pathlib.Path(temporary) / "source.zip"
            try:
                release.source_archive(ROOT, output)
            except ValueError as error:
                self.fail(f"Repository cannot be packaged: {error}")
            with zipfile.ZipFile(output) as package:
                names = set(package.namelist())
                self.assertEqual(reports - names, set(), "all verification reports must ship")
                documents = {name: package.read(name).decode("utf-8-sig")
                             for name in names if name.endswith(".md")}
                self.assertEqual(self.missing_document_links(documents, names), [])


class ReleaseTests(unittest.TestCase):
    def setUp(self):
        spec = importlib.util.spec_from_file_location("release", ROOT / "scripts/release.py")
        self.assertTrue(spec.origin and pathlib.Path(spec.origin).is_file(),
                        "release packaging implementation is missing")
        self.release = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.release)
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = pathlib.Path(self.tmp.name) / "project"
        self.root.mkdir()
        for name in self.release.ROOT_FILES:
            path = self.root / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text("fixture\n", encoding="utf-8")
        (self.root / "VERSION").write_text("1.0.0-rc1\n")
        for name in self.release.SOURCE_DIRS:
            folder = self.root / name
            folder.mkdir(parents=True, exist_ok=True)
            (folder / "example.txt").write_text("source")

    def prepare_juce(self):
        archive = self.root / "deps/JUCE-9.0.4.zip"
        directory = self.root / "deps/JUCE-9.0.4"
        directory.mkdir(parents=True)
        (directory / "module.h").write_bytes(b"original dependency")
        with zipfile.ZipFile(archive, "w") as package:
            package.writestr("JUCE-9.0.4/module.h", b"original dependency")
        return directory, hashlib.sha256(archive.read_bytes()).hexdigest()

    def test_modified_missing_or_extra_juce_source_is_rejected(self):
        directory, expected = self.prepare_juce()
        self.assertEqual(self.release.verify_juce(self.root, directory, expected), expected)
        (directory / "module.h").write_bytes(b"local modification")
        with self.assertRaisesRegex(ValueError, "JUCE"):
            self.release.verify_juce(self.root, directory, expected)
        (directory / "module.h").write_bytes(b"original dependency")
        (directory / "extra.h").write_text("extra source")
        with self.assertRaisesRegex(ValueError, "JUCE"):
            self.release.verify_juce(self.root, directory, expected)
        (directory / "extra.h").unlink()
        (directory / "module.h").unlink()
        with self.assertRaisesRegex(ValueError, "JUCE"):
            self.release.verify_juce(self.root, directory, expected)

    def test_source_edit_during_packaging_cannot_produce_an_artifact(self):
        binary = self.root / "DualDeck.exe"
        binary.write_bytes(b"MZfixture")
        _, expected = self.prepare_juce()
        self.release.stamp(self.root, binary, self.release.fingerprint(self.root), juce_hash=expected)
        archive = self.release.source_archive

        def edit_after_archiving(root, output):
            result = archive(root, output)
            (self.root / "Source/example.txt").write_text("concurrent edit")
            return result

        output = pathlib.Path(self.tmp.name) / "raced"
        with mock.patch.object(self.release, "source_archive", side_effect=edit_after_archiving):
            with self.assertRaisesRegex(ValueError, "source"):
                self.release.bundle(self.root, binary, output, juce_hash=expected)
        self.assertFalse(output.exists())

    def test_source_excludes_private_and_generated_files(self):
        for name in ("data", "sounds", "deps", "tools", "keyboard-runtime", "test-output", ".git"):
            folder = self.root / name
            folder.mkdir(exist_ok=True)
            (folder / "PRIVATE").write_text("must never ship")
        (self.root / "Source/__pycache__").mkdir()
        (self.root / "Source/__pycache__/cached.pyc").write_bytes(b"cache")
        output = pathlib.Path(self.tmp.name) / "source.zip"
        self.release.source_archive(self.root, output)
        with zipfile.ZipFile(output) as package:
            names = package.namelist()
            self.assertIn("Source/example.txt", names)
            self.assertIn(".github/example.txt", names)
            self.assertFalse(any("PRIVATE" in n or "__pycache__" in n for n in names))
            self.assertNotIn("scripts/portable-msvc.py", names)

    def test_missing_required_file_and_existing_output_are_rejected(self):
        output = pathlib.Path(self.tmp.name) / "source.zip"
        (self.root / "LICENSE").unlink()
        with self.assertRaisesRegex(ValueError, "LICENSE"):
            self.release.source_archive(self.root, output)
        self.assertFalse(output.exists())
        (self.root / "LICENSE").write_text("license")
        output.write_bytes(b"preserve")
        with self.assertRaises(FileExistsError):
            self.release.source_archive(self.root, output)
        self.assertEqual(output.read_bytes(), b"preserve")

    def test_link_cannot_import_a_private_file(self):
        private = pathlib.Path(self.tmp.name) / "private.txt"
        private.write_text("private")
        try:
            (self.root / "Source/linked.txt").symlink_to(private)
        except OSError:
            self.skipTest("Windows symbolic-link privilege unavailable")
        with self.assertRaisesRegex(ValueError, "link"):
            self.release.source_archive(self.root, pathlib.Path(self.tmp.name) / "source.zip")

    def test_versions_reject_paths_and_stable_is_not_a_candidate(self):
        for bad in ("../private", "1.0.0/rc1", "1.0.0 rc1", "1.0.0"):
            (self.root / "VERSION").write_text(bad)
            with self.assertRaises(ValueError):
                self.release.read_version(self.root)

    def test_binary_bundle_contains_corresponding_source_and_no_driver(self):
        binary = self.root / "DualDeck.exe"
        binary.write_bytes(b"MZ" + b"test fixture")
        juce = self.root / "deps/JUCE-9.0.4.zip"
        juce.parent.mkdir()
        juce.write_bytes(b"dependency fixture")
        runtime = self.root / "keyboard-runtime"
        runtime.mkdir()
        (runtime / "interception.dll").write_bytes(b"private local DLL must not ship")
        (runtime / "keyboard.sys").write_bytes(b"private local driver must not ship")
        output = pathlib.Path(self.tmp.name) / "artifacts"
        expected = hashlib.sha256(juce.read_bytes()).hexdigest()
        self.release.stamp(self.root, binary, self.release.fingerprint(self.root), juce_hash=expected)
        self.release.bundle(self.root, binary, output, juce_hash=expected)
        with zipfile.ZipFile(output / "DualDeck-1.0.0-rc1-windows-x64-preview.zip") as package:
            names = package.namelist()
            self.assertIn("DualDeck.exe", names)
            self.assertIn("source/DualDeck-1.0.0-rc1-source.zip", names)
            self.assertIn("source/JUCE-9.0.4.zip", names)
            self.assertIn("keyboard-runtime/LEGGIMI.txt", names)
            self.assertEqual([n for n in names if n.startswith("keyboard-runtime/")],
                             ["keyboard-runtime/LEGGIMI.txt"])
            instructions = package.read("keyboard-runtime/LEGGIMI.txt").decode("utf-8")
            self.assertIn("Interception/library/x64/interception.dll", instructions)
            self.assertIn("https://github.com/oblitum/Interception/releases/tag/v1.0.1", instructions)
            self.assertIn("AB88164C11B1B48488772D4C3BFAA4509D5B0AE9DBC5A691DC4F96F0260443C8", instructions)
            self.assertIn("driver", instructions)
            self.assertFalse(any(n.endswith((".dll", ".sys")) for n in names))
            manifest = json.loads(package.read("BUILD-INFO.json"))
            self.assertEqual(manifest["status"], "preview-not-for-stable-release")
            self.assertFalse(manifest["interception_bundled"])
            self.assertEqual(manifest["binary_sha256"], hashlib.sha256(binary.read_bytes()).hexdigest())
        checksums = (output / "SHA256SUMS.txt").read_text()
        for archive in output.glob("*.zip"):
            self.assertIn(hashlib.sha256(archive.read_bytes()).hexdigest(), checksums)

    def test_modified_sources_or_binary_cannot_be_paired_with_an_old_build(self):
        binary = self.root / "DualDeck.exe"
        binary.write_bytes(b"MZfixture")
        juce = self.root / "deps/JUCE-9.0.4.zip"
        juce.parent.mkdir()
        juce.write_bytes(b"fixture")
        expected = hashlib.sha256(juce.read_bytes()).hexdigest()
        self.release.stamp(self.root, binary, self.release.fingerprint(self.root), juce_hash=expected)
        (self.root / "Source/example.txt").write_text("changed after compilation")
        with self.assertRaisesRegex(ValueError, "source"):
            self.release.bundle(self.root, binary, pathlib.Path(self.tmp.name) / "bad-source", juce_hash=expected)
        self.release.stamp(self.root, binary, self.release.fingerprint(self.root), juce_hash=expected)
        binary.write_bytes(b"MZchanged")
        with self.assertRaisesRegex(ValueError, "binary"):
            self.release.bundle(self.root, binary, pathlib.Path(self.tmp.name) / "bad-binary", juce_hash=expected)

    def test_source_changes_during_build_are_rejected(self):
        before = self.release.fingerprint(self.root)
        (self.root / "Source/example.txt").write_text("changed during build")
        binary = self.root / "DualDeck.exe"
        binary.write_bytes(b"MZfixture")
        with self.assertRaisesRegex(ValueError, "source"):
            self.release.stamp(self.root, binary, before)

    def test_wrong_dependency_is_rejected_before_any_artifact_is_written(self):
        binary = self.root / "DualDeck.exe"
        binary.write_bytes(b"MZfixture")
        juce = self.root / "deps/JUCE-9.0.4.zip"
        juce.parent.mkdir()
        juce.write_bytes(b"tampered")
        output = pathlib.Path(self.tmp.name) / "artifacts"
        with self.assertRaisesRegex(ValueError, "JUCE"):
            self.release.bundle(self.root, binary, output)
        self.assertFalse(output.exists())


if __name__ == "__main__":
    unittest.main()
